# PROMPT MAESTRO — Claude Code

> Copia este archivo entero y pégalo como primer mensaje a Claude Code dentro del repo `taxivtc-platform`.

---

Hola Claude. Vamos a rediseñar el frontend de esta plataforma VTC (`taxivtc-platform`) aplicando el design system **NORA** — estética premium oscura tipo Bolt. El backend NO se toca; los endpoints y modelos de datos son sagrados.

## Contexto

En la carpeta `handoff/` de este mismo repo tienes toda la documentación:

- `handoff/README.md` — índice
- `handoff/01_design_system.md` — tokens (colores, tipografía, radios, sombras)
- `handoff/02_api_contract.md` — endpoints del backend (NO cambiar)
- `handoff/03_data_models.md` — tipos TS (User, Trip, Driver, etc.)
- `handoff/04_screens_passenger.md` — especificación de cada pantalla del pasajero
- `handoff/05_screens_driver.md` — íd conductor
- `handoff/06_screens_admin.md` — íd admin
- `handoff/07_component_library.md` — componentes reutilizables a crear en `src/components/ui/`
- `handoff/08_realtime.md` — guía SSE
- `handoff/09_deployment_railway.md` — deploy (para después)
- `handoff/preview/index.html` — diseño objetivo en HTML estático. Ábrelo para ver cómo debe quedar.

## Reglas de oro

1. **No toques `src/lib/api.ts` ni `src/store/authStore.ts`** — funcionan bien.
2. **No cambies URLs de endpoints ni nombres de campos** — el contrato con el backend es inmutable.
3. **Usa los tipos de `handoff/03_data_models.md`** — créalos en `src/types/` como módulos TS compartidos.
4. **Antes de tocar una pantalla, lee su spec completa** en `handoff/0X_screens_*.md`.
5. **Antes de crear un componente grande, revisa `handoff/07_component_library.md`** para ver si ya está definido allí.
6. **Pide confirmación antes de:**
   - Instalar dependencias nuevas
   - Cambiar la estructura de rutas (`src/App.tsx`)
   - Modificar la forma en que se hace auth

## Plan por fases

Ejecuta en este orden. Al terminar cada fase, haz commit con mensaje `chore(nora): fase N — <descripción>` y espérame para confirmar antes de seguir.

### Fase 1 — Fundación

1. Crea `src/styles/tokens.css` con todas las variables CSS de `handoff/01_design_system.md`. Impórtalo en `src/main.tsx`.
2. En `index.html`, añade los `<link>` de Google Fonts (Instrument Serif, Geist, Geist Mono).
3. Crea `src/types/api.ts` con todos los modelos de `handoff/03_data_models.md`.
4. Sustituye los `any` en `src/pages/**` por estos tipos (sin refactor visual aún).
5. Commit.

### Fase 2 — Librería de componentes UI

1. Crea `src/components/ui/` con: `Button`, `Card`, `Input`, `Chip`, `StatusDot`, `Spinner`, `Logo`, `TripStatusChip`, `PaymentBadge`, `MapContainer`.
2. Cada componente:
   - En su propio archivo
   - Con tipos exportados
   - Sigue la spec de `handoff/07_component_library.md`
3. Crea `src/components/ui/index.ts` como barrel export.
4. Crea una ruta temporal `/_dev/kitchen-sink` que renderice todos los componentes en todos sus estados para verificación visual.
5. Commit.

### Fase 3 — Login + Register

1. Rediseña `src/pages/Login.tsx` con los nuevos componentes, siguiendo estética NORA (fondo `--bg`, logo grande, card oscura con borde `--line`).
2. Rediseña `src/pages/Register.tsx` (selector de rol como 2 cards grandes con icono).
3. Rediseña `src/components/AppLoading.tsx` con Spinner NORA.
4. Commit.

### Fase 4 — App Pasajero

1. Refactoriza `src/pages/passenger/Home.tsx` dividiéndolo en sub-componentes:
   - `src/components/passenger/IdlePanel.tsx` (P1)
   - `src/components/passenger/QuotePanel.tsx` (P2)
   - `src/components/passenger/SearchingPanel.tsx` (P3)
   - `src/components/passenger/OnTripPanel.tsx` (P4)
   - `src/components/passenger/PaymentPanel.tsx` (P5)
   - `src/components/passenger/BottomNav.tsx`
2. `Home.tsx` se queda como orquestador de estado + render condicional según `step`.
3. Sigue cada spec de `handoff/04_screens_passenger.md` al pie de la letra.
4. Google Maps en modo oscuro (mapId ya está en el repo, verifica que cargue bien).
5. Commit.

### Fase 5 — App Conductor

1. Misma división:
   - `OfflineState.tsx` (D1)
   - `OnlineState.tsx` (D2) — sin solicitudes
   - `RequestCard.tsx` (D3) — con progress bar del `expiresAt`
   - `ActiveTripCard.tsx` (D4–D8) — card clara con estados
   - `AvailabilityToggle.tsx`
   - `EarningsCard.tsx`
   - `BottomNav.tsx`
2. `DriverMap.tsx` se mantiene en su lugar (lógica buena) pero aplica estilos NORA a los markers.
3. Sigue `handoff/05_screens_driver.md`.
4. Commit.

### Fase 6 — Admin Dashboard

1. Dividir `src/pages/admin/Home.tsx`:
   - `AdminSidebar.tsx`
   - `AdminTopbar.tsx` con métricas live
   - `views/LiveMapView.tsx`
   - `views/TripsView.tsx`
   - `views/DriversView.tsx`
   - `views/LicensesView.tsx`
   - `views/PricingRulesView.tsx`
2. Tabla reutilizable `src/components/ui/DataTable.tsx` con columnas configurables.
3. Sigue `handoff/06_screens_admin.md`.
4. Commit.

### Fase 7 — Realtime y polish

1. Hook `useTripSSE(tripId)` en `src/hooks/useTripSSE.ts` con la lógica de `handoff/08_realtime.md`.
2. Hook `useDriverLocationsSSE()` para el admin.
3. Banner global de "Reconectando…" si `!connected`.
4. Micro-interacciones: animaciones de entrada en paneles (framer-motion / motion.react ya está instalado).
5. Commit.

### Fase 8 — QA manual

1. Levanta el backend localmente
2. Crea usuarios de prueba (passenger1, driver1, admin1)
3. Prueba el flujo completo en 3 navegadores abiertos a la vez
4. Anota bugs
5. Arregla

## Stack del repo (no cambiar)

- Vite + React 18 + TypeScript
- React Router v6
- Zustand (auth store persistente)
- TanStack Query
- @react-google-maps/api
- motion.react (framer-motion v11)
- lucide-react (iconos)
- Tailwind — lo mantenemos para layout utility, pero colores y tokens van vía CSS vars del design system

## Cómo quiero que comuniques

- Al empezar cada fase, escribe un plan corto (3-5 bullets) de lo que vas a tocar.
- Al terminar, resume qué se creó/modificó y muéstrame el diff de archivos clave.
- Si encuentras algo ambiguo en la spec, PREGUNTA antes de decidir.
- Si encuentras un bug preexistente en el repo (no de diseño, de lógica), señálalo pero NO lo arregles salvo que te lo confirme.

**Empieza por la Fase 1.** Cuando termines, haz commit y espera confirmación.

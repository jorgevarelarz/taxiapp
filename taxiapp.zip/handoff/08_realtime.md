# Real-time (SSE)

El repo usa Server-Sent Events, no WebSockets. Eso simplifica el deploy (funciona sobre HTTP normal) pero hay algunos gotchas.

## Patrón general

```tsx
useEffect(() => {
  const eventSource = new EventSource(`/api/events/trips?tripId=${tripId}`);

  eventSource.addEventListener('trip_update', async (e) => {
    // Opción A: usar el payload directo
    const partial = JSON.parse(e.data);
    setTrip((prev) => ({ ...prev, ...partial }));

    // Opción B (más segura): re-fetchear el trip completo
    const full = await fetchJson(`/api/passenger/trips/${tripId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    setTrip(full);
  });

  return () => eventSource.close();
}, [tripId, token]);
```

**Recomendado:** opción B (re-fetch) cuando el update cambia de estado o de pago. Opción A solo para location updates (mucho volumen).

## Canales

### `/api/events/trips` (global, para conductores)

Eventos:
- `new_trip` — llega una oferta nueva. El conductor debe re-fetchear `/api/driver/requests`.
- `trip_update` — un trip cambió de estado. Si coincide con `activeTrip.id`, refetch. Si no, ignora.

### `/api/events/trips?tripId=<id>` (específico, para pasajero)

Eventos:
- `trip_update` — solo de ese trip. Refetch y actualiza UI.

### `/api/events/drivers` (global ubicaciones)

Eventos:
- `driver_location_update` — payload `{ driverId, lat, lng, heading }`. Muy frecuente (cada 5–10s por conductor).

Consumers:
- **Admin** — mantén `Record<driverId, location>` y muévelos en el mapa
- **Pasajero** durante `on-trip` — filtra solo por su `activeTrip.driver.id` y muestra marker

## Reconexión

El navegador reconecta automáticamente en caso de desconexión. Para mostrar estado "reconectando" al usuario:

```tsx
eventSource.onerror = () => setConnected(false);
eventSource.onopen = () => setConnected(true);
```

Banner opcional arriba: "Conectando…" cuando `!connected`.

## Cuidado con re-renders

Los events de location llegan muy rápido. **No metas `liveDrivers` en props de componentes grandes** que re-renderen. Pásalos directamente al MapContainer y memoiza los markers:

```tsx
const markers = useMemo(
  () => Object.values(liveDrivers).map(...),
  [liveDrivers]
);
```

## Limpieza

Siempre `eventSource.close()` en el cleanup del useEffect, o dejarás conexiones fantasma cuando el componente unmount.

## Testing local

El repo tiene un seed/mock para testing. Para simular events sin backend real, puedes usar:

```ts
// src/lib/mockEventSource.ts (solo dev)
export const mockTripUpdate = (partial: Partial<Trip>) => {
  window.dispatchEvent(new CustomEvent('mock_trip_update', { detail: partial }));
};
```

Y en el hook, escucha el custom event además de EventSource cuando `import.meta.env.DEV`. Pregúntale a Claude Code que lo añada si lo necesitas.

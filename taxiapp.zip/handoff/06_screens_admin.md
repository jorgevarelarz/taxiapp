# Pantallas — Dashboard Admin

Stack: `/admin/*`. Layout desktop con sidebar fija. Fondo oscuro consistente con la marca.

## Layout general

```
┌─────────────┬──────────────────────────────────────┐
│             │ Topbar (60px)                         │
│  Sidebar    ├──────────────────────────────────────┤
│   200px     │                                       │
│             │ Main content                          │
│             │                                       │
│             │                                       │
└─────────────┴──────────────────────────────────────┘
```

## Sidebar

- Ancho 240px, borde derecho `--line`
- Logo NORA + badge "ADMIN" arriba
- Nav items (icono + label + counter):
  - Live Map
  - Viajes ({trips.length})
  - Conductores ({drivers.length})
  - Licencias ({licenses.length})
  - Tarifas ({rules.length})
- Logout abajo del todo

Estilo de nav item activo:
- Fondo `rgba(212,255,58,0.08)`, texto `--accent`
- Borde izquierdo 2px `--accent`

## Topbar

- A la derecha: chip "N conductores online" con dot verde pulsante
- Buscador global (placeholder)
- Avatar del admin

## A1. Live Map

**Ruta:** `/admin` (view === 'map')

- Mapa Google ocupa toda el área principal (fondo oscuro)
- Un marker por conductor online (flecha con heading)
- Marker actual del admin oculto
- Overlay flotante top-right: métricas en vivo
  - Conductores online: {N}
  - Viajes activos: {count de trips con status in progress}
  - Gross today: €XXX

**Endpoints:**
- SSE `/api/events/drivers` — escuchar `driver_location_update`, mantener `liveDrivers` state como `Record<driverId, {lat,lng,heading}>`
- `GET /api/admin/trips` para contar activos (filtrar status)

## A2. Viajes

- Header con filtros: estado · método de pago · rango de fecha (aún sin endpoint, pon filtros client-side)
- Tabla con columnas:
  - Ref (`bookingReference`, mono)
  - Pasajero (`passenger.user.name`)
  - Ruta (`originText` → `destinationText`, truncado)
  - Estado (chip coloreado)
  - Pago (`paymentMethod` + `paymentStatus`)
  - Precio final (Instrument Serif 16px)
  - Fecha (`createdAt`, formato "DD MMM, HH:mm")

Fila al hover: fondo `rgba(255,255,255,0.02)`.

**Endpoints:** `GET /api/admin/trips`

## A3. Conductores

- Tabla:
  - Avatar + Nombre
  - Email
  - Licencia (`licenseNumber`, mono)
  - Estado (`status` con dot)
  - Verificación (`verificationStatus`, chip)

**Endpoints:** `GET /api/admin/drivers`

## A4. Licencias

- Tabla:
  - Código (`licenseCode`, mono, Geist 600)
  - Municipio (`municipality`)
  - Titular (`ownerName`)
  - Activa (toggle visual, readonly por ahora)
  - Conductores asociados (count con chevron → detalle)

**Endpoints:** `GET /api/admin/licenses`

## A5. Reglas de precio

- Cards por ciudad:
  - Ciudad en serif grande
  - Grid 2×2: Tarifa base · Mínima · €/km día · €/km noche
  - Badge "NOCHE 22:00 – 06:00"

**Endpoints:** `GET /api/admin/pricing-rules`

## KPIs en cada vista (summary cards)

Cuando estás en Viajes/Conductores/etc, muestra 4 cards resumen arriba:
- Total viajes
- Total conductores
- Licencias activas
- Reglas vigentes

Estos son los `summaryCards` que ya tienes en `AdminHome.tsx`. Mantén esa lógica; solo aplica estilos NORA.

## Paleta específica del admin

Aunque compartimos el design system, el admin puede ser ligeramente **menos oscuro** que el mobile para lectura prolongada:
- Fondo main: `--panel` en lugar de `--bg`
- Cards: `--panel-2`

El mapa sigue en modo oscuro completo.

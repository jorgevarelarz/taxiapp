# Component Library

Componentes React reutilizables. Vamos a crearlos en `src/components/ui/`. Todos usan los tokens del design system.

## Estructura sugerida

```
src/
├── components/
│   ├── ui/
│   │   ├── Button.tsx
│   │   ├── Card.tsx
│   │   ├── Input.tsx
│   │   ├── Chip.tsx
│   │   ├── StatusDot.tsx
│   │   ├── Spinner.tsx
│   │   ├── Logo.tsx
│   │   └── index.ts
│   ├── passenger/
│   ├── driver/
│   └── admin/
└── styles/
    ├── tokens.css          # Las variables CSS de 01_design_system.md
    └── globals.css
```

## Button

```tsx
interface ButtonProps {
  variant?: 'primary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
  disabled?: boolean;
  loading?: boolean;
  leftIcon?: ReactNode;
  rightIcon?: ReactNode;
  onClick?: () => void;
  children: ReactNode;
}
```

- `primary` → fondo `--accent`, texto `--accent-ink`, peso 700
- `ghost` → fondo `rgba(255,255,255,0.06)`, borde `--line`, texto `--ink`
- `danger` → fondo `rgba(255,90,95,0.1)`, borde `rgba(255,90,95,0.3)`, texto `--danger`
- Radio 16px, padding 16×22 (md)
- `loading` → muestra `<Spinner size="sm" />` a la izq
- Active: `transform: scale(0.98)` (100ms)
- Disabled: `opacity 0.35`

## Card

```tsx
interface CardProps {
  variant?: 'dark' | 'light' | 'nested';
  padding?: 'sm' | 'md' | 'lg';
  children: ReactNode;
}
```

- `dark` → fondo `--panel`, borde `--line`, radio 20px
- `light` → fondo `#FAFAFB`, texto oscuro (para la card de viaje del conductor)
- `nested` → fondo `--panel-2`, radio 16px

## Input

```tsx
interface InputProps {
  label?: string;          // se muestra como eyebrow arriba
  icon?: ReactNode;        // izq
  error?: string;
  ...
}
```

- Sin border por defecto, solo border-bottom `--line`
- En focus: border-bottom `--accent`
- Label en eyebrow (10–11px, uppercase, letter-spacing 0.22em, `--ink-3`)

Ejemplo de uso en la home del pasajero:

```tsx
<Input
  label="Recogida"
  icon={<MapPin />}
  placeholder="¿Dónde te recogemos?"
  value={origin.text}
  onChange={...}
/>
```

## Chip

```tsx
interface ChipProps {
  variant?: 'dark' | 'accent' | 'danger' | 'warn' | 'ok';
  size?: 'sm' | 'md';
  leftIcon?: ReactNode;
  children: ReactNode;
}
```

Radio 999, padding 4×10, font-size 11, peso 500.

## StatusDot

Dot 6×6 + label opcional. Colores por estado:

```tsx
<StatusDot status="online" />     // verde
<StatusDot status="busy" />       // ámbar
<StatusDot status="offline" />    // gris
<StatusDot status="active" pulse /> // verde acento con animación
```

## Logo

Componente reutilizable:

```tsx
<Logo size="sm" />        // 32px, solo mark
<Logo size="md" />        // 44px, mark + "NORA"
<Logo size="lg" showTagline />  // 64px + "A CORUÑA · VTC"
```

- Mark: cuadrado `--accent` con "N" en `--accent-ink`, peso 800, Geist
- Wordmark: "NORA" en Instrument Serif 32px

## Spinner

- `size: 'sm' | 'md' | 'lg'` → 16 / 24 / 40px
- Color: `currentColor` (hereda)
- Animación rotate 1s linear infinite

## TripStatusChip

Chip especializado que traduce `TripStatus` a texto + color:

```tsx
<TripStatusChip status={trip.status} />
```

Mapping:
- `requested` → warn "Solicitado"
- `driver_en_route` → accent "Conductor en camino"
- `arrived_at_pickup` → accent "En el punto"
- `passenger_on_board` → ok "A bordo"
- `in_progress` → ok "En curso"
- `completed` → dark "Completado"
- `cancelled` → danger "Cancelado"
- `no_show` → danger "No show"

## PaymentBadge

```tsx
<PaymentBadge method={trip.paymentMethod} status={trip.paymentStatus} />
```

Combina método + estado en un solo chip:
- `in_app` + `paid` → ok "Pagado · App"
- `in_app` + `processing` → warn "Procesando · App"
- `cash` + `paid` → dark "Pagado · Efectivo"
- `cash` + `pending` → warn "Pendiente · Efectivo"

## MapContainer

Wrapper para Google Maps con estilo oscuro preconfigurado:

```tsx
<MapContainer
  center={{ lat: 43.3623, lng: -8.4115 }}
  zoom={13}
  style="dark"
>
  {/* Markers, polylines, etc */}
</MapContainer>
```

Estilo oscuro: usa `mapId: 'b19f4a8d3f54d4de'` (ya lo tienes configurado en el repo) o define uno nuevo en Google Cloud Console.

## Iconos

Sigue usando **lucide-react** — ya está instalado y funciona bien con el design system. Stroke width 1.75 por defecto para un look un poco más fino.

Iconos clave por pantalla:
- Pasajero: `MapPin`, `Search`, `CreditCard`, `Car`, `User`, `Clock`, `ChevronRight`, `ShieldCheck`, `Star`, `History`, `LogOut`
- Conductor: `Navigation`, `Car`, `Bell`, `AlertCircle`, `TrendingUp`, `Wallet`, `User`, `Star`, `CheckCircle2`
- Admin: `Map`, `List`, `Users`, `ShieldCheck`, `DollarSign`, `LogOut`

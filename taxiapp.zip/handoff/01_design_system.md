# NORA — Design System

## Marca

- **Nombre:** NORA
- **Descripción corta:** Transporte premium en A Coruña
- **Logotipo:** Letra "N" sobre cuadrado de color acento (`#D4FF3A`), radio 12px
- **Voz:** Directa, confiable, sin adornos. Español de España.

## Tokens

### Colores

```css
:root {
  /* Superficies */
  --bg: #09090B;            /* Fondo principal (casi negro) */
  --panel: #111114;         /* Paneles, cards */
  --panel-2: #17171B;       /* Paneles anidados */
  --line: #24242A;          /* Bordes sutiles */
  --line-2: #2E2E35;        /* Bordes hover */

  /* Texto */
  --ink: #F5F5F7;           /* Texto principal */
  --ink-2: #B5B5BD;         /* Texto secundario */
  --ink-3: #6E6E78;         /* Texto terciario / labels */
  --ink-4: #3F3F48;         /* Texto deshabilitado */

  /* Acento (CTA principal, highlights) */
  --accent: #D4FF3A;        /* Verde lima eléctrico */
  --accent-ink: #0A0A0B;    /* Texto sobre acento */

  /* Estados */
  --danger: #FF5A5F;
  --warn: #FFB020;
  --ok: #7AE582;
}
```

**Superficie clara para conductor cuando el viaje está activo:**
Cuando un viaje está en curso, la card del pasajero en la app del conductor usa fondo `#FAFAFB` con texto `#0A0A0B` — es una inversión intencional que señala "este es el contenido importante AHORA".

### Tipografía

Dos familias, importadas de Google Fonts:

```html
<link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Geist:wght@300;400;500;600;700;800&family=Geist+Mono:wght@400;500&display=swap" rel="stylesheet">
```

- **Geist** (sans) — UI, labels, body. Pesos 400/500/600/700/800.
- **Instrument Serif** (serif) — titulares grandes, precios, números hero. Italic disponible para énfasis.
- **Geist Mono** — matrículas, referencias de booking, IDs.

### Escala tipográfica

| Token | Tamaño | Familia | Uso |
|---|---|---|---|
| `text-hero` | 48–64px | Instrument Serif | Precio grande en quote |
| `text-display` | 32–40px | Instrument Serif | Títulos de sección |
| `text-xl` | 20px | Geist 600 | Títulos de card |
| `text-lg` | 16px | Geist 500 | Body destacado |
| `text-base` | 14px | Geist 400 | Body |
| `text-sm` | 13px | Geist 400 | Secundario |
| `text-xs` | 11–12px | Geist 500 | Labels |
| `text-eyebrow` | 10–11px | Geist 600, letter-spacing 0.22em, uppercase | Eyebrows, metadatos |

### Espaciado

Sistema base 4px. Usar múltiplos: 4, 8, 12, 16, 20, 24, 32, 40, 56, 80.

### Radios

- `6px` — elementos pequeños (swatch, badge)
- `10–12px` — botones, inputs, chips
- `16px` — cards pequeñas
- `20–24px` — cards principales, paneles
- `999px` — pills, avatars

### Sombras

```css
--shadow-sm: 0 2px 8px rgba(0,0,0,0.3);
--shadow-md: 0 8px 24px rgba(0,0,0,0.4);
--shadow-lg: 0 30px 60px rgba(0,0,0,0.5);
--shadow-glow: 0 0 24px rgba(212,255,58,0.3);  /* acento */
```

## Componentes base

### Botón primario

Fondo `--accent`, texto `--accent-ink`, peso 700, padding 16×22, radio 16.

### Botón fantasma

Fondo `rgba(255,255,255,0.06)`, borde `--line`, texto `--ink`.

### Pill (filtro, toggle pequeño)

Fondo `--panel`, borde `--line`, padding 8×14, radio 999, texto 12px peso 500.
Activo: fondo `--ink`, texto `--bg`.

### Chip (badge de estado)

Padding 4×10, radio 999, font-size 11px, peso 500.
- `chip-dark` → fondo `rgba(255,255,255,0.08)`, texto `--ink-2`
- `chip-accent` → fondo `--accent`, texto `--accent-ink`

### Dot (indicador de estado)

6×6px, radio 999. Colores: `--ok` (online), `--warn` (busy), `--danger` (sin conexión), `--accent` (activo).

## Accesibilidad

- Contraste mínimo 4.5:1 texto sobre fondo. Los tokens están validados.
- Touch targets mínimo 44×44px (apps móviles).
- El acento `#D4FF3A` sobre negro tiene contraste AAA.

## Ver en vivo

Abre `preview/index.html` (incluido en este handoff) para ver todos los componentes y pantallas en contexto.

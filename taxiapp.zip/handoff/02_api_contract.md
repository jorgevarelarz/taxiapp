# API Contract — taxivtc-platform

Todos los endpoints tal como están implementados en tu backend actual. **No los modifiques.** El frontend NORA se construye alrededor de este contrato.

## Autenticación

Base: `/api/auth`

| Método | Endpoint | Body | Respuesta |
|---|---|---|---|
| `POST` | `/api/auth/login` | `{ email, password }` | `{ user, token }` o `{ error }` |
| `POST` | `/api/auth/register` | `{ email, password, name, phone, role }` | `{ user, token }` |
| `POST` | `/api/auth/logout` | — | 200 OK |
| `GET` | `/api/auth/me` | — (cookie de sesión) | `User` o 401 |

`role` en registro: `'passenger' | 'driver'` (admin/operator se crean por otro canal).

## Pasajero

Base: `/api/passenger` — todos requieren `Authorization: Bearer <token>`.

| Método | Endpoint | Body / Params | Respuesta |
|---|---|---|---|
| `POST` | `/api/passenger/quote` | `{ originText, destinationText }` | `Quote` |
| `POST` | `/api/passenger/trips` | `{ origin, destination, agreedPrice, distanceMeters, durationSeconds, pricingRuleId, breakdown, paymentMethod }` | `Trip` |
| `GET` | `/api/passenger/trips/active` | — | `Trip \| null` |
| `GET` | `/api/passenger/trips/:id` | — | `Trip` (con driver anidado) |
| `POST` | `/api/passenger/trips/:id/cancel` | — | `Trip` |
| `POST` | `/api/passenger/trips/:id/payment/confirm` | — | `Trip` (paymentStatus actualizado) |

`paymentMethod`: `'in_app' | 'cash'`.

## Conductor

Base: `/api/driver` — todos requieren token.

| Método | Endpoint | Body / Params | Respuesta |
|---|---|---|---|
| `POST` | `/api/driver/status` | `{ status: 'online' \| 'offline' }` | 200 OK |
| `GET` | `/api/driver/requests` | — | `TripRequest[]` |
| `GET` | `/api/driver/trips/active` | — | `Trip \| null` |
| `GET` | `/api/driver/trips/:id` | — | `Trip` |
| `POST` | `/api/driver/trips/:id/accept` | `{ offerId }` | `Trip` |
| `POST` | `/api/driver/trips/:id/reject` | `{ offerId }` | 200 OK |
| `POST` | `/api/driver/trips/:id/status` | `{ status }` | `Trip` |
| `POST` | `/api/driver/trips/:id/payment/collect` | — | `Trip` |
| `POST` | `/api/driver/location` | `{ lat, lng, heading? }` | 200 OK |

`status` válidos en `/status`: `driver_en_route`, `arrived_at_pickup`, `passenger_on_board`, `in_progress`, `completed`, `no_show`.

## Admin

Base: `/api/admin` — requiere rol `admin`.

| Método | Endpoint | Respuesta |
|---|---|---|
| `GET` | `/api/admin/trips` | `Trip[]` |
| `GET` | `/api/admin/drivers` | `Driver[]` |
| `GET` | `/api/admin/licenses` | `License[]` |
| `GET` | `/api/admin/pricing-rules` | `PricingRule[]` |

## Server-Sent Events (realtime)

Canales:

| Endpoint | Eventos | Consumer |
|---|---|---|
| `/api/events/trips` (global) | `new_trip`, `trip_update` | Conductor (escucha todas) |
| `/api/events/trips?tripId=<id>` | `trip_update` | Pasajero (solo su viaje) |
| `/api/events/drivers` | `driver_location_update` | Admin (todos), Pasajero (su conductor) |

Ver `08_realtime.md` para el detalle del payload de cada evento.

## Variables de entorno

El frontend necesita:

```
VITE_GOOGLE_MAPS_API_KEY=<tu_api_key>
```

El backend (no lo tocamos, pero para referencia de Railway):
```
DATABASE_URL=postgresql://...
JWT_SECRET=...
SESSION_SECRET=...
GOOGLE_MAPS_SERVER_KEY=...   # para validación de direcciones en /quote
```

# Pantallas — App Conductor

Stack: `/driver/*`. Fondo oscuro siempre (el conductor trabaja mucho de noche). Max-width 480px en móvil.

## D1. Home — Offline

**Ruta:** `/driver` (cuando `status === 'offline'`)

**Layout:**
- Header: logo "NORA DRIVER" a la izq, badge con licencia "LIC-1234", campana (notificaciones) y logout a la der
- Mapa (30vh) con ubicación actual, atenuado (opacity 0.5)
- Card ganancias "Ganancias hoy" — placeholder 0,00€ en offline
- Toggle grande de disponibilidad (ver abajo)
- Zona vacía con ilustración centrada:
  - Icono coche 48px gris oscuro en cuadrado
  - Badge rojo con "!" superpuesto
  - Título italic "Sin conexión"
  - Texto: "Ponte en línea para empezar a recibir servicios y generar ingresos hoy"

## D2. Home — Online (sin solicitudes)

**Ruta:** misma, `status === 'online'`, `requests.length === 0`

- Mapa con ubicación actual (marker verde acento)
- Card ganancias real (`124.50€` mock hasta que haya endpoint)
- Toggle en "Disponible" (verde con glow)
- Sección solicitudes: estado vacío con animación ping ("Escaneando zona…")

**Endpoints:**
- `POST /api/driver/status` al tocar el toggle
- `GET /api/driver/requests` cada vez que status cambia a online
- `POST /api/driver/location` cada vez que `geolocation.watchPosition` emite (cada 10s)
- SSE `/api/events/trips` para `new_trip`

## D3. Solicitud entrante

**Ruta:** misma, cuando llega `new_trip` y `/requests` devuelve items.

**Card por solicitud:**
- Header: avatar pasajero 40px + nombre (Geist 700) + rating + booking ref (mono)
- A la derecha: precio grande + "PRECIO PACTADO"
- Mini-mapa textual: origen + destino con dots
- Métricas debajo (si hay): "a X km" + "ETA Y min" (calculadas desde currentLocation)
- 2 botones: "Rechazar" (ghost) + "Aceptar" (flex 2, primario blanco)
- Barra de progreso debajo — linear a 0% en `expiresAt - now` segundos

**Endpoints:**
- `POST /api/driver/trips/:id/accept` con `{ offerId }`
- `POST /api/driver/trips/:id/reject` con `{ offerId }`

## D4. Viaje activo — En camino a recogida

**Ruta:** misma, `activeTrip !== null` y `status === 'driver_en_route'`

- Mapa 40vh: ruta verde (pickup) desde ubicación actual al origen
- 2 cards métricas lado a lado: "Hasta recogida" (tiempo + km) · "Trayecto" (tiempo + km)
- Card ganancias + toggle (deshabilitado en busy)
- **Card de viaje activo — fondo CLARO** (`--surface-light`):
  - Avatar pasajero + nombre
  - Precio pactado + ref
  - Lista ruta (dots origen/destino)
  - Botón primario: "He llegado al punto"

**Endpoints:**
- `POST /api/driver/trips/:id/status` con `{ status: 'arrived_at_pickup' }`

## D5. Viaje activo — En el punto

- Igual que D4 pero:
- Mapa sin ruta pickup (ya llegamos)
- Botones:
  - "No show" (ghost rojo, flex 1)
  - "Pasajero a bordo" (verde primario, flex 2)

**Endpoints:**
- `POST /api/driver/trips/:id/status` con `{ status: 'no_show' | 'passenger_on_board' }`

## D6. Viaje activo — A bordo

- Mapa con ruta completa del viaje (blanco, 4px)
- Card clara con info
- Botón primario: "Iniciar viaje"

**Endpoints:**
- `POST /api/driver/trips/:id/status` con `{ status: 'in_progress' }`

## D7. Viaje activo — En curso

- Mapa igual
- Botón primario: "Finalizar viaje"

**Endpoints:**
- `POST /api/driver/trips/:id/status` con `{ status: 'completed' }`

## D8. Completado — Cobro

- Si `paymentMethod === 'cash'` + `paymentStatus === 'pending'`:
  - Botón verde: "Cobrar {finalPrice}€ en efectivo"
  - `POST /api/driver/trips/:id/payment/collect`
- Si `paymentMethod === 'in_app'` + `paymentStatus === 'processing'`:
  - Estado deshabilitado con spinner: "Esperando pago en app…"
- Si `paymentStatus === 'paid'`:
  - Botón gris: "Viaje completado" — limpia el estado y vuelve a online

## Componentes específicos del conductor

### Toggle de disponibilidad

- Contenedor: 64×36, fondo `--panel-2` en offline / `--ok` con glow en online
- Thumb: 24×24 blanco, anim 500ms al cambiar
- Deshabilitado cuando `status === 'busy'`

### Barra de progreso de solicitud

- Altura 4px, fondo `--line`
- Fill blanco, width animado de 100% → 0% en (`expiresAt - now`) segundos, easing linear

## Geolocalización

- `navigator.geolocation.watchPosition` con `enableHighAccuracy: true`
- Enviar `{ lat, lng, heading }` a `POST /api/driver/location` en cada update
- Si no hay permiso → banner warning: "Activa la ubicación para mejorar el mapa y el reparto"

# NORA — Handoff para Claude Code

Este paquete contiene todo lo necesario para construir **NORA**, plataforma VTC para A Coruña, tomando como base tu repo `taxivtc-platform` y aplicando el nuevo design system.

## ¿Qué hay aquí?

| Archivo | Para qué sirve |
|---|---|
| `PROMPT_CLAUDE_CODE.md` | **El prompt maestro.** Cópialo entero y pégalo en Claude Code como primer mensaje. |
| `01_design_system.md` | Tokens de diseño (colores, tipografía, espaciados, radios, sombras). |
| `02_api_contract.md` | Todos los endpoints del backend del repo, agrupados por rol. |
| `03_data_models.md` | Modelos TypeScript de User, Trip, Driver, License, PricingRule. |
| `04_screens_passenger.md` | Especificación pantalla a pantalla del flujo pasajero (con endpoints y estados). |
| `05_screens_driver.md` | Lo mismo para el conductor. |
| `06_screens_admin.md` | Lo mismo para el dashboard admin. |
| `07_component_library.md` | Componentes reutilizables (Button, Card, StatusChip, etc). |
| `08_realtime.md` | Guía de Server-Sent Events y sincronización en tiempo real. |
| `09_deployment_railway.md` | Guía de despliegue en Railway paso a paso. |
| `preview/` | HTML estático del prototipo NORA — abre `preview/index.html` para ver el diseño objetivo. |

## Cómo usarlo

1. **Abre tu proyecto `taxivtc-platform` en Claude Code** (o clónalo si aún no lo tienes local).
2. **Copia esta carpeta `handoff/` dentro del repo** (al mismo nivel que `src/`).
3. **Abre `preview/index.html`** en el navegador — esto es lo que vas a construir.
4. **Abre Claude Code y pega el contenido de `PROMPT_CLAUDE_CODE.md`** como primer mensaje.
5. Claude Code irá aplicando los cambios por pantallas, preguntándote antes de tocar cosas sensibles (autenticación, API).

## Filosofía

- **NO reescribimos el backend.** Los endpoints son sagrados.
- **NO inventamos campos nuevos.** Usamos exactamente los modelos que devuelve la API.
- **SÍ rediseñamos el frontend** con el design system NORA (premium oscuro).
- **SÍ mantenemos React + Vite + Zustand + TanStack Query** — el stack actual es bueno.

## Estado del repo actual (taxivtc-platform)

- ✅ Autenticación funcionando (`/api/auth/login`, `/api/auth/register`, `/api/auth/me`)
- ✅ Flujo pasajero completo (quote → request → trip → payment)
- ✅ Flujo conductor completo (online/offline → aceptar → estados → cobro)
- ✅ Dashboard admin (live map + trips + drivers + licenses + pricing rules)
- ✅ Server-Sent Events para updates en vivo
- ✅ Google Maps integrado (necesita `VITE_GOOGLE_MAPS_API_KEY`)
- ⚠️ Diseño actual es tailwind básico en blanco → esto es lo que rediseñamos

# Data Models

Tipos TypeScript de lo que devuelve la API. Úsalos tal cual en el frontend NORA.

## User

```ts
interface User {
  id: string;
  email: string;
  name: string;
  role: 'passenger' | 'driver' | 'operator' | 'admin';
  passenger?: { id: string };
  driver?: { id: string; status: string };
}
```

## Quote

Respuesta de `POST /api/passenger/quote`:

```ts
interface Quote {
  origin: { text: string; coords: { lat: number; lng: number } };
  destination: { text: string; coords: { lat: number; lng: number } };
  estimatedPrice: number;      // EUR
  distanceMeters: number;
  durationSeconds: number;
  pricingRuleId: string;
  city: string;                // "A Coruña"
  breakdown: {
    base: number;
    distance: number;
    time: number;
    minimum?: number;
  };
}
```

## Trip

Modelo central. Devuelto por quote→create, active, y eventos.

```ts
type TripStatus =
  | 'requested'
  | 'driver_en_route'
  | 'arrived_at_pickup'
  | 'passenger_on_board'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | 'no_show';

type PaymentMethod = 'in_app' | 'cash';
type PaymentStatus = 'pending' | 'processing' | 'paid' | 'failed';
type DispatchStatus = 'dispatching' | 'driver_assigned' | 'no_driver_found';

interface Trip {
  id: string;
  bookingReference: string;        // ej. "NR-8421"
  status: TripStatus;
  dispatchStatus?: DispatchStatus;

  // Ubicaciones
  originText: string;
  originLat: number;
  originLng: number;
  destinationText: string;
  destinationLat: number;
  destinationLng: number;

  // Precio
  agreedPrice: number;
  finalPrice?: number;
  estimatedPrice?: number;
  distanceMeters: number;
  durationSeconds: number;

  // Pago
  paymentMethod: PaymentMethod;
  paymentStatus: PaymentStatus;

  // Relaciones (anidadas cuando procede)
  passenger?: {
    id: string;
    user: { id: string; name: string; phone?: string };
  };
  driver?: {
    id: string;
    licenseNumber: string;
    user: { id: string; name: string; phone?: string };
  };

  createdAt: string;
  updatedAt: string;
}
```

## TripRequest

Lo que recibe el conductor en `GET /api/driver/requests`:

```ts
interface TripRequest {
  id: string;                  // trip id
  offerId: string;             // token para accept/reject
  bookingReference: string;
  passenger: { user: { name: string } };

  originText: string;
  originLat: number;
  originLng: number;
  destinationText: string;
  destinationLat: number;
  destinationLng: number;

  agreedPrice?: number;
  estimatedPrice: number;
  routeDistanceMeters?: number;
  routeDurationSeconds?: number;

  expiresAt: string;           // ISO — usar para el countdown
}
```

## Driver

```ts
interface Driver {
  id: string;
  licenseNumber: string;
  status: 'online' | 'offline' | 'busy';
  verificationStatus: 'pending' | 'verified' | 'rejected';
  user: { id: string; name: string; email: string; phone: string };
  currentLat?: number;
  currentLng?: number;
}
```

## License

```ts
interface License {
  id: string;
  licenseCode: string;
  municipality: string;        // "A Coruña"
  ownerName: string;
  isActive: boolean;
  drivers?: Driver[];
}
```

## PricingRule

```ts
interface PricingRule {
  id: string;
  city: string;
  baseFare: number;
  minimumFare: number;
  perKmDay: number;
  perKmNight: number;
  perMinute?: number;
  nightStartHour?: number;     // 22
  nightEndHour?: number;       // 6
}
```

## Eventos SSE

```ts
// Canal: /api/events/trips
interface TripUpdateEvent {
  type: 'trip_update';
  data: Partial<Trip>;         // puedes recibir solo id+status, re-fetcheas el resto
}

interface NewTripEvent {
  type: 'new_trip';
  data: { tripId: string };    // conductor debe re-fetchear /requests
}

// Canal: /api/events/drivers
interface DriverLocationEvent {
  type: 'driver_location_update';
  data: {
    driverId: string;
    lat: number;
    lng: number;
    heading: number;
  };
}
```

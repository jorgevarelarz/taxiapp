# Despliegue en Railway

Tienes dos servicios a desplegar: **frontend** (este repo `taxivtc-platform`) y **backend** (el que ya tienes en algún sitio — asumo mismo repo en monorepo o repo aparte).

## Prerrequisitos

1. Cuenta Railway creada
2. Railway CLI instalado (opcional pero cómodo): `npm i -g @railway/cli`
3. API key de Google Maps:
   - Habilitar: Maps JavaScript API, Places API, Directions API, Distance Matrix API
   - Restricciones: HTTP referrers con el dominio de tu Railway deploy

## Opción A — Monorepo (recomendado si frontend y backend están juntos)

### 1. Estructura

```
repo/
├── packages/
│   ├── frontend/   # taxivtc-platform
│   └── backend/    # tu api
├── package.json
└── railway.json
```

### 2. `railway.json` en la raíz

```json
{
  "$schema": "https://railway.app/railway.schema.json",
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "npm run start",
    "healthcheckPath": "/api/health",
    "healthcheckTimeout": 300,
    "restartPolicyType": "ON_FAILURE"
  }
}
```

### 3. Variables de entorno (Railway → Variables)

Frontend (build-time):
- `VITE_GOOGLE_MAPS_API_KEY` — tu API key pública (restringida por dominio)
- `VITE_API_URL` — URL del backend si está en otro servicio, si no deja vacío

Backend:
- `DATABASE_URL` — Railway te la genera si añades el plugin Postgres
- `JWT_SECRET` — genera con `openssl rand -base64 32`
- `SESSION_SECRET` — idem
- `GOOGLE_MAPS_SERVER_KEY` — otra API key sin restricción de referrer
- `NODE_ENV=production`
- `PORT` — Railway la asigna automáticamente

## Opción B — Frontend y backend como servicios separados

### Frontend

1. Railway → New Project → Deploy from GitHub
2. Selecciona el repo, root path `packages/frontend` (o raíz si no es monorepo)
3. Build: `npm ci && npm run build`
4. Start: `npm run preview -- --port $PORT --host 0.0.0.0`
5. En Settings → Generate Domain

### Backend

Idem, con sus propias vars.

### Configurar CORS

Si están en dominios distintos, el backend necesita:

```ts
app.use(cors({
  origin: process.env.FRONTEND_URL,
  credentials: true,
}));
```

Y en el frontend, cambiar las fetch a URL absoluta:

```ts
const API = import.meta.env.VITE_API_URL || '';
await fetch(`${API}/api/auth/login`, { credentials: 'include', ... });
```

## Postgres en Railway

1. En tu proyecto: + New → Database → PostgreSQL
2. Railway genera `DATABASE_URL` automáticamente
3. Ejecutar migraciones como release command:
   - Settings → Deploy → Custom Start Command: `npm run migrate && npm run start`

## Dominio custom

1. Railway → Settings → Networking → Custom Domain
2. Añade `nora.taxi` (o el que elijas)
3. Railway te da los DNS records — configúralos en tu registrar

## Monitorización mínima

- Railway tiene logs en vivo por servicio
- Para alertas, conecta Sentry en el frontend:
  ```bash
  npm i @sentry/react
  ```
  Y añade `VITE_SENTRY_DSN` a las vars

## Costes estimados (primer MVP)

- Frontend (static-ish): ~$5/mes
- Backend: ~$5–10/mes según tráfico
- Postgres: ~$5/mes starter
- **Total: ~$15–20/mes**

Google Maps: con <100 pasajeros/día, estás muy por debajo de los $200 gratis mensuales.

## Checklist pre-lanzamiento

- [ ] Variables de entorno todas configuradas
- [ ] HTTPS activo (Railway lo da automáticamente)
- [ ] Google Maps restringido al dominio de producción
- [ ] Migraciones corridas en prod
- [ ] Al menos una licencia activa en BD
- [ ] Al menos una PricingRule para "A Coruña" en BD
- [ ] Un conductor verificado y online para probar
- [ ] Login funcional con cuenta real de prueba
- [ ] Flujo completo pasajero → conductor probado end-to-end en staging
- [ ] Política de privacidad y términos (obligatorio VTC)
- [ ] Registro en la Xunta como operador VTC (consulta con abogado local)

## Después del MVP

- Push notifications (OneSignal o Firebase)
- Apps nativas (Capacitor sobre el mismo frontend)
- Pagos con Stripe o Redsys
- Integración con AEAT para facturación automática

# Pantallas — App Pasajero

Stack: React Router `/passenger/*`. Layout: full-height, max-width 480px centrado, fondo `--bg`.

## P1. Home — Idle (pedir viaje)

**Ruta:** `/passenger` (cuando `step === 'idle'`)

**Layout:**
- Header fijo (60px): logo NORA a la izquierda, botón historial + logout a la derecha
- Mapa (40vh) — Google Maps en modo oscuro, sin UI, con pin en ubicación actual
- Card flotante superpuesta al mapa (margin-top negativo -32px):
  - Eyebrow "RECOGIDA" + input con autocomplete (Google Places)
  - Separador
  - Eyebrow "DESTINO" + input con autocomplete
  - Botón primario full-width "Solicitar presupuesto"

**Estados:**
- `destination.coords === null` → botón deshabilitado
- `isSubmittingQuote` → botón muestra "Calculando…" con spinner mono

**Endpoints:**
- `POST /api/passenger/quote` con `{ originText, destinationText }`

**Copy real (usar tal cual):**
- Placeholder origen: "¿Dónde te recogemos?"
- Placeholder destino: "¿A dónde vas?"
- Botón: "Solicitar presupuesto"

## P2. Quote — Presupuesto

**Ruta:** misma, `step === 'quoting'` tras respuesta del quote

**Layout:**
- Header idem
- Mapa (35vh) con la ruta dibujada (`DirectionsRenderer`)
- Card grande:
  - Eyebrow "PRECIO CERRADO"
  - Precio hero en Instrument Serif 56px + "€"
  - Chip verde acento: "✓ GARANTIZADO"
  - Subtítulo Geist 14px: "Acuerdo electrónico de servicio"
  - Grid 2 columnas metadatos:
    - "Distancia" → `(quote.distanceMeters / 1000).toFixed(1)} km`
    - "Tiempo" → `~{Math.round(quote.durationSeconds / 60)} min`
  - Separador
  - Selector método pago (2 botones lado a lado): "Pago en app" / "Efectivo"
  - 2 botones: "Atrás" (ghost) + "Pedir ahora" (primario, flex 2)

**Endpoints:**
- `POST /api/passenger/trips` con el quote validado + paymentMethod

## P3. Searching — Buscando conductor

**Ruta:** misma, `step === 'searching'`

**Layout:**
- Sin mapa (lo reemplazamos por pantalla focus)
- Animación central: círculo 128px con spinner de acento pulsante + icono coche dentro
- Título 24px italic: "Buscando Taxi"
- Subtítulo: "Estamos asignando el vehículo más cercano a tu posición en A Coruña"
- Botón ghost pequeño abajo: "Cancelar"

**Estado especial `dispatchStatus === 'no_driver_found'`:**
- Cambia color del círculo a danger
- Título: "Sin conductores"
- Mensaje: "No hay conductores disponibles en este momento. Por favor, inténtalo de nuevo en unos minutos."
- Botón principal: "Volver al inicio"

**Endpoints:**
- `POST /api/passenger/trips/:id/cancel`
- SSE `/api/events/trips?tripId=<id>` — escucha `trip_update`

## P4. On-Trip — Viaje en curso

**Ruta:** misma, `step === 'on-trip'`

**Layout:**
- Mapa 50vh, centrado en ubicación del conductor en vivo, marker con heading
- Card "Conductor":
  - Avatar circular 56px
  - Nombre (Geist 600) + estrella 4.9
  - A la derecha: pill blanca con `licenseNumber`, label "Matrícula" debajo
- Lista vertical de ruta (origen→destino) con puntos de color
- Footer:
  - Estado con dot verde pulsante + texto según `activeTrip.status`:
    - `driver_en_route` → "Conductor en camino"
    - `arrived_at_pickup` → "Taxi en el punto"
    - `passenger_on_board` → "Pasajero a bordo"
    - `in_progress` → "Viaje en curso"
  - Eyebrow "Ref: {bookingReference}"
  - Precio a la derecha (Instrument Serif 32px)

**Endpoints:**
- SSE `/api/events/trips?tripId=<id>` para cambios de estado
- SSE `/api/events/drivers` para ubicación del conductor

## P5. Payment — Pago final

**Ruta:** misma, `step === 'payment'` (status completed + paymentStatus != paid)

**Layout:**
- Check verde grande centrado (icono en círculo de `--ok`)
- Título italic: "Viaje completado"
- Subtítulo: "Por favor, completa el pago para finalizar"
- Card de total:
  - Eyebrow "TOTAL A PAGAR"
  - Precio hero Instrument Serif 56px
- Si `paymentMethod === 'cash'`:
  - Banner warning: "Por favor, abona el importe en efectivo al conductor"
- Si `paymentMethod === 'in_app'`:
  - Botón primario full-width "Pagar ahora" con icono tarjeta

**Endpoints:**
- `POST /api/passenger/trips/:id/payment/confirm`

## Navegación inferior (persistente)

Tab bar fija (altura 72px), fondo `--panel`, borde superior `--line`:
- Viaje (activo) — icono coche
- Historial — icono reloj
- Perfil — icono usuario

Los tabs "Historial" y "Perfil" están fuera de scope para este MVP; muéstralos con un placeholder "Próximamente" si el usuario los pulsa.

## Errores

Banner rojo en la parte superior del main (debajo del header), fondo `rgba(255,90,95,0.1)`, borde `rgba(255,90,95,0.3)`, texto `#FFB5B8`. Muestra `uiError` y se cierra con click.
